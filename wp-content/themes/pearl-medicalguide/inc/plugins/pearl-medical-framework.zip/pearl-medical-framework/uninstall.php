<?php

/**
 * @link       http://themeforest.net/user/pearlthemes
 * @since      1.0.0
 *
 * @package    Pearl_Medical_Framework
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
